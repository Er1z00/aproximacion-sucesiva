
import GUI.GUI;

public class Aproximaciones {
    public static void main(String[] args) {
       GUI g = new GUI ();
        g.setVisible(true);
        g.setTitle("Metodo de Aproximaciones Sucesivas");
    }
    
}
